<template>
	<div class="custom-input m__birthdate">
		<label class="form-label" >birthdate
			<input type="text" class="form-input " placeholder="19.02.2018" maxlength="10">
		</label>
		
		<span class="error"></span>
	</div>
</template>


<script >
	

	module.exports = {
		data: function() {
			return {
				
			}
		
		}

	}
</script>