<template>
<div>
	<div class="custom-input ">
		<label class="form-label" >email
			<input v-validate="'required|email'" type="email" name="email" placeholder="your@email.com" class="form-input" autofocus >
		</label>
	
	</div>
		<span class="validate-error" v-if="errors.has('email')">{{ errors.first('email') }}</span>
</div>
</template>


<script >
	

	module.exports = {
		data: function() {
			return {
				
			}
		
		}

	}
</script>