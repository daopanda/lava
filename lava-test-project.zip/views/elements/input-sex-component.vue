<template>
	<div class="sex-wrapper">
		
			<div class="sex-checkbox">
				
			</div>
			<div class="sex-checkbox">
				
			</div>
		

	</div>
</template>


<script >
	

	module.exports = {
		data: function() {
			return {
				
			}
		
		}

	}
</script>