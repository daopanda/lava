
<template>
	<div class="custom-input ci-password">
		<label class="form-label" > password
			<input :type="showType"  class="form-input" >
		</label>
		<span class="button-check_password" @click="showtypeflag = !showtypeflag"></span>
		<span class="error"></span>
	</div>
</template>


<script >
	

	module.exports = {
		data: function() {
			return {
      			showtypeflag: true
    		}
  		},
  		computed: {
  	 			showType: function () {
      				return this.showtypeflag ? 'password' : 'text';
    				}
  			}
		
		

	}
</script>

