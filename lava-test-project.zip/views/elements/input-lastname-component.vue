<template>
	<div class="custom-input">
		<label class="form-label" >last name
			<input type="text" class="form-input" autofocus>
		</label>
		<span class="error"></span>
	</div>
</template>


<script >
	

	module.exports = {
		data: function() {
			return {
				
			}
		
		}

	}
</script>