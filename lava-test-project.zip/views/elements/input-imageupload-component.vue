<template>
	<div class="upload-image">
		
		

	</div>
</template>


<script >
	

	module.exports = {
		data: function() {
			return {
				
			}
		
		}

	}
</script>