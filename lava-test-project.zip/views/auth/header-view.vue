<template>
	<header id="top-panel">		
		<a href="#" id="logotype">
		<img src="imgs/logo.svg" >
		LAVA
		</a>
	
	</header>
</template>

<script >
	module.exports = {
		data: function() {
			return {
				
			}
		}

	}
</script>